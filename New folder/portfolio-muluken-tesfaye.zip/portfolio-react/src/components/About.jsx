export default function About() {
  return (
    <section id="about" className="section">
      <div className="container">
        <h2 className="section-title">About Me</h2>
        <div className="about-content reveal">
          <div className="about-text">
            <p>
              I’m a Computer Engineering educator and full-stack developer specializing in building modern web applications using <strong>Node.js</strong>, <strong>React</strong>, <strong>PHP</strong>, and relational databases.
            </p>
            <p>
              When I’m not teaching or working on curriculum architecture, I enjoy exploring database systems, algorithm optimization, and practical AI tools for software development.
            </p>
            <p>
              I combine strong engineering fundamentals with a passion for education to create solutions that are both technically solid and user-focused.
            </p>
          </div>
          <div className="about-cards">
            <div className="info-card">
              <h3>Focus</h3>
              <p>Full Stack Development</p>
            </div>
            <div className="info-card">
              <h3>Role</h3>
              <p>Educator & Developer</p>
            </div>
            <div className="info-card">
              <h3>Interests</h3>
              <p>Databases • Algorithms • AI Tools</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
