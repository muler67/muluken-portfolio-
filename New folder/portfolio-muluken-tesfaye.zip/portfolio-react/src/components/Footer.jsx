export default function Footer() {
  const year = new Date().getFullYear()

  return (
    <footer className="footer">
      <div className="container">
        <p>© {year} Muluken Tesfaye. Built with React.</p>
      </div>
    </footer>
  )
}
