export default function Education() {
  return (
    <section id="education" className="section section-alt">
      <div className="container">
        <h2 className="section-title">Education</h2>
        <div className="education-card reveal">
          <div className="edu-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M22 10v6M2 10l10-5 10 5-10 5z"/>
              <path d="M6 12v5c3 3 9 3 12 0v-5"/>
            </svg>
          </div>
          <div className="edu-content">
            <h3>Bachelor of Science in Electrical and Computer Engineering</h3>
            <p className="edu-school">Hawassa University</p>
            <p className="edu-focus">Computer Engineering specialization</p>
          </div>
        </div>
      </div>
    </section>
  )
}
